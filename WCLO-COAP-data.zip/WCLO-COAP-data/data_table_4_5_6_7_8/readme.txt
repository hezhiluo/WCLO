test instances for table 4 :
  n    m    r    data name
  40  20  10   wclo1-wclo5
  50  30  10   wclo101-wclo105
  60  40  10   wclo106-wclo110
  80  40  10   wclo11-wclo15
  40  20  15   wclo71-wclo75
  50  20  15   wclo116-wclo120
  60  40  15   wclo126-wclo130
  40  20  20   wclo26-wclo30
  50  20  20   wclo81-wclo85
  60  30  20   wclo31-wclo35
  80  40  20   wclo36-wclo40
  40  30  30   wclo131-wclo135
  50  30  30   wclo86-wclo90 
  60  30  30   wclo51-wclo55
  80  40  30   wclo56-wclo60
  50  40  40   wclo136-wclo140
  60  40  40   wclo181-wclo185

test instances for table 5 :
  n    m    r    data name
  40  20  10   wclo1-wclo5
  40  30  10   wclo96-wclo100
  50  20  10   wclo76-wclo80
  50  30  10   wclo101-wclo105
  60  30  10   wclo6-wclo10
  60  40  10   wclo106-wclo110
  40  15  15   wclo146-wclo150
  40  20  15   wclo71-wclo75
  40  30  15   wclo111-wclo115
  50  20  15   wclo116-wclo120
  60  30  15   wclo121-wclo125
  60  40  15   wclo126-wclo130

test instances for table 6 :
  n    m    r    data name
  40  20  20   wclo26-wclo30
  40  30  30   wclo131-wclo135
  50  20  20   wclo81-wclo85
  50  30  30   wclo86-wclo90
  50  35  35   wclo176-wclo180
  50  40  40   wclo136-wclo140
  60  30  20   wclo31-wclo35
  60  25  25   wclo156-wclo160
  60  30  30   wclo51-wclo55
  60  40  40   wclo186-wclo190

test instances for table 7 :
  n    m    r    data name
  80  40  10   wclo11-wclo15
  80  40  20   wclo36-wclo40
  80  30  30   wclo161-wclo165
  80  40  30   wclo56-wclo60
100  50  10   wclo16-wclo20
100  50  20   wclo41-wclo45
100  50  30   wclo61-wclo65
100  40  40   wclo171-wclo175
120  60  10   wclo21-wclo25
120  60  20   wclo46-wclo50
120  60  30   wclo66-wclo70

test instances for table 8 :
 n<=60: the same test instances for table 6
   n>60: the same test instances for table 7