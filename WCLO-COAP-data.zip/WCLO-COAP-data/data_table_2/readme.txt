  n    m    r    data name
  40  30  20   wclo1-wclo5
  60  30  20   wclo6-wclo10
  80  30  20   wclo11-wclo15
100  30  20   wclo16-wclo20
120  30  20   wclo21-wclo25