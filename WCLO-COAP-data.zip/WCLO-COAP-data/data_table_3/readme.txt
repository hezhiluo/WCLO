  n    m    r    data name
  60  40  30   wclo31-wclo35
  80  40  30   wclo36-wclo40
100  40  30   wclo41-wclo45
120  40  30   wclo46-wclo50